# R-kode brugt i projektet



### Indlæsning
D <- read.table("soenderborg1_data.csv", header=TRUE, sep=";",
                as.is=TRUE)

### Kapitel 1.a

## Indledende analyse af datasættet
dim(D)
names(D)
head(D)
tail(D)
summary(D)
str(D)


### Kapitel 1.b

## Histogram for varmeforbrug i hus 1
hist(D$Q1, xlab="Varmeforbrug (hus 1) / [kW/dag]", prob=TRUE, main="")


### Kapitel 1.c

## Omdannelse til dato-variabel
D$t <- as.Date(x=D$t, format="%Y-%m-%d")
summary(D$t)

## Plot varmeforbruget over tid
plot(D$t, D$Q1, type="l", xlim=as.Date(c("2008-10-02","2010-10-01")),
     ylim=c(0,9), xlab="Dato", ylab="Varmeforbrug / [kW/dag]", col=2,
     main="")
lines(D$t, D$Q2, col=3)
lines(D$t, D$Q3, col=4)
lines(D$t, D$Q4, col=5)
legend("topright", legend=paste0("Hus Q",c(1,2,3,4)), lty=1, col=2:5)


### Kapitel 1.d

## Udvælg data fra januar og februar 2010
Dsel <- subset(D, "2010-01-01" <= t & t < "2010-3-01")

## Boxplot for varmeforbrug opdelt efter hus
boxplot(Dsel[ ,c("Q1","Q2","Q3","Q4")],
        xlab="Hus", ylab="Varmeforbrug")


### Kapitel 1.e

## Udforskning af data i perioden
sum(!is.na(Dsel$Q1))
mean(Dsel$Q1, na.rm=TRUE)
var(Dsel$Q1, na.rm=TRUE)
sd(Dsel$Q1, na.rm=TRUE)
quantile(Dsel$Q1, na.rm=TRUE, type=2)

sum(!is.na(Dsel$Q2))
mean(Dsel$Q2, na.rm=TRUE)
var(Dsel$Q2, na.rm=TRUE)
sd(Dsel$Q2, na.rm=TRUE)
quantile(Dsel$Q2, na.rm=TRUE, type=2)

sum(!is.na(Dsel$Q3))
mean(Dsel$Q3, na.rm=TRUE)
var(Dsel$Q3, na.rm=TRUE)
sd(Dsel$Q3, na.rm=TRUE)
quantile(Dsel$Q3, na.rm=TRUE, type=2)

sum(!is.na(Dsel$Q4))
mean(Dsel$Q4, na.rm=TRUE)
var(Dsel$Q4, na.rm=TRUE)
sd(Dsel$Q4, na.rm=TRUE)
quantile(Dsel$Q4, na.rm=TRUE, type=2)


### Kapitel 2.f

## QQ-plot for hvert af de 4 huse i den givne periode
qqnorm(Dsel$Q1, main="Hus Q1", xlab="Teoretiske kvantiler",
       ylab="Prøvekvantiler",
       cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
qqline(Dsel$Q1)

qqnorm(Dsel$Q2, main="Hus Q2", xlab="Teoretiske kvantiler",
       ylab="Prøvekvantiler",
       cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
qqline(Dsel$Q2)

qqnorm(Dsel$Q3, main="Hus Q3", xlab="Teoretiske kvantiler",
       ylab="Prøvekvantiler",
       cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
qqline(Dsel$Q3)

qqnorm(Dsel$Q4, main="Hus Q4", xlab="Teoretiske kvantiler",
       ylab="Prøvekvantiler",
       cex.lab=1.5, cex.axis=1.5, cex.main=1.5, cex.sub=1.5)
qqline(Dsel$Q4)

## Opstilling af modeller
mean(Dsel$Q1, na.rm=TRUE); var(Dsel$Q1, na.rm=TRUE)
mean(Dsel$Q2, na.rm=TRUE); var(Dsel$Q2, na.rm=TRUE)
mean(Dsel$Q3, na.rm=TRUE); var(Dsel$Q3, na.rm=TRUE)
mean(Dsel$Q4, na.rm=TRUE); var(Dsel$Q4, na.rm=TRUE)


### Kapitel 2.g

## Konfidensinterval for middelværdi

## Hus 1
mean(Dsel$Q1, na.rm=TRUE) - qt(0.975, 54) * sd(Dsel$Q1, na.rm=TRUE) / sqrt(55)
mean(Dsel$Q1, na.rm=TRUE) + qt(0.975, 54) * sd(Dsel$Q1, na.rm=TRUE) / sqrt(55)

## Hus 2
mean(Dsel$Q2, na.rm=TRUE) - qt(0.975, 55) * sd(Dsel$Q2, na.rm=TRUE) / sqrt(56)
mean(Dsel$Q2, na.rm=TRUE) + qt(0.975, 55) * sd(Dsel$Q2, na.rm=TRUE) / sqrt(56)

## Hus 3
mean(Dsel$Q3, na.rm=TRUE) - qt(0.975, 54) * sd(Dsel$Q3, na.rm=TRUE) / sqrt(55)
mean(Dsel$Q3, na.rm=TRUE) + qt(0.975, 54) * sd(Dsel$Q3, na.rm=TRUE) / sqrt(55)

## Hus 4
mean(Dsel$Q4, na.rm=TRUE) - qt(0.975, 56) * sd(Dsel$Q4, na.rm=TRUE) / sqrt(57)
mean(Dsel$Q4, na.rm=TRUE) + qt(0.975, 56) * sd(Dsel$Q4, na.rm=TRUE) / sqrt(57)

## Samme beregning med indbyggede funktioner
t.test(Dsel$Q1, conf.level=0.95)$conf.int
t.test(Dsel$Q2, conf.level=0.95)$conf.int
t.test(Dsel$Q3, conf.level=0.95)$conf.int
t.test(Dsel$Q4, conf.level=0.95)$conf.int


### Kapitel 2.h

## Udførelse af t-test
x_h <- Dsel$Q1
n_h <- sum(!is.na((x_h)))
mean_h <- mean(x_h, na.rm=TRUE)
sd_h <- sd(x_h, na.rm=TRUE)
tobs_h <- (mean_h - 2.38) / (sd_h / sqrt(n_h))
pvalue_h <- 2 * (1-pt(abs(tobs_h), df=n_h-1))
print(pvalue_h)

## Samme beregning med indbyggede funktioner
t.test(Dsel$Q1, mu=2.38)


### Kapitel 2.i

## Udførelse af t-test
x1_i = Dsel$Q1
x2_i = Dsel$Q2
n1_i = sum(!is.na(x1_i))
n2_i = sum(!is.na(x2_i))
mean1_i = mean(x1_i, na.rm=TRUE)
mean2_i = mean(x2_i, na.rm=TRUE)
s1_i = sd(x1_i, na.rm=TRUE)
s2_i = sd(x2_i, na.rm=TRUE)
tobs_i = ((mean1_i - mean2_i)-0) / (sqrt(s1_i**2/n1_i + s2_i**2/n2_i))

## Udregning af v
v = ((s1_i**2)/n1_i + (s2_i**2)/n2_i)**2 / (((s1_i**2 / n1_i)**2/(n1_i-1)) + ((s2_i**2 / n2_i)**2/(n2_i-1)))

## p
2 * (1 - pt(tobs_i, df=v))

## Samme som ovenstående, bare med indbygget funktion
t.test(Dsel$Q1, Dsel$Q2)


### Kapitel 2.k

## Kovarians og standardafvigelse samt korrelation
s_xy_k = cov(D$Q1, D$G, use="complete.obs")
s_x_k = sd(D$Q1, na.rm=TRUE)
s_y_k = sd(D$G, na.rm=TRUE)
s_xy_k / (s_x_k * s_y_k)

## Beregning af korrelation mellem Q1 og G
cor(D[, c("Q1","G")], use="pairwise.complete.obs")

## Scatterplot
plot(D$Q1, D$G, xlab="Varmeforbrug hus 1", ylab="Global indstråling")
