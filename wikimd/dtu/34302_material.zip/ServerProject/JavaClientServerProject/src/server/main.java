package server;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;
import java.util.TimeZone;

public class main {

    /**
     * Åben socket, modtag indkommende data og process indkommende data
     * @author Emil Petersen (s214687), Jonathan Svarer Johansen (s214682) og Daniel Brasholt (s214675)
     * @param args
     * @exception IOException Fejl hvis socket ikke can åbne
     */
    public static void main(String[] args) {
        ServerSocket server_sock = null;
        boolean server_active = true;
        try {
            server_sock = new ServerSocket(8080);
            while (server_active) {
                try {
                    Socket client_socket = server_sock.accept();

                    // Kill server if url /LUK is requested
                    String requested_resource = getRequest(client_socket);
                    if (requested_resource.equals("/LUK")) {
                        server_active = false;
                    }
                    // Redirect to index.html
                    if (requested_resource.equals("/")) {
                        requested_resource = "/index.html";
                    }
                    //Files.list(Paths.get("./html")).forEach(path -> System.out.println(path));
                    sendResource(requested_resource, client_socket);


                    client_socket.shutdownInput();
                    client_socket.shutdownOutput();
                    client_socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            server_sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Find nuværende dato til at inkludere i HTTP header
     * @return  dato som String
     **/
    public static String getDate() {
        SimpleDateFormat gmtFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.
                ENGLISH
        );
        gmtFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        String gmtString = gmtFormat.format(Calendar.getInstance().getTime());
        return gmtString;
    }

    /**
     * Set størrelse på buffer.
     * Hent den anmodede fil i /HTML mappen og send HTTP header med filen
     * @param request anmodne fil
     * @param client_socket åben socket
     * @exception IOException
     */
    public static void sendResource(String request, Socket client_socket) {
        try {
            BufferedOutputStream bos = new BufferedOutputStream(client_socket.getOutputStream());
            boolean file_exists = false;
            FileInputStream fin = null;
            File file=null;

            String date = "Date: " + getDate();

            // Vælg anmodede fil og send HTTP header med status kode 404 hvis fil ikke eksisterer
            try {
                file = new File("./html" + request);
                fin = new FileInputStream(file);
                file_exists = true;

            } catch (FileNotFoundException e) {
                bos.write("HTTP/1.0 404 \r\n".getBytes(StandardCharsets.UTF_8));
                bos.write("Content-Length: 0\r\n".getBytes(StandardCharsets.UTF_8));
                bos.write("Content-Type: text/plain\r\n".getBytes(StandardCharsets.UTF_8));
                bos.write(date.getBytes(StandardCharsets.UTF_8));
                bos.write("\r\n\r\n".getBytes(StandardCharsets.UTF_8));
                bos.write("404\n".getBytes(StandardCharsets.UTF_8));
                bos.flush(); // Standard 404-side i plain text sendes, hvis den anmodede fil ikke kan læses
            }

            if (file_exists) {
                writePageToOutputStream(file, fin, date, bos); // Skriv filen til outputstream, hvis den eksisterer
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Skriv en fil til output stream.
     * Hent den anmodede fil i /HTML mappen og send HTTP header med filen
     * @param file anmodne fil
     * @param fin FileInputStream som er deklareret på forhånd
     * @param date tidspunkt, der kan sendes i header
     * @param bos BufferedOutputStream, som sendes til klienten
     * @exception IOException kaster IOException hvis filen ikke kan læses eller der ikke kan skrives til BOS
     */
    public static void writePageToOutputStream(File file, FileInputStream fin, String date, BufferedOutputStream bos) {
        long file_size = file.length(); // Længden af file (bruges til Content-Length header
        String fileType="text/plain"; // default type

        try {
            // Tjek fil type og sæt input til content header
            fileType = switch (Files.probeContentType(file.toPath())) {
                case "text/html" -> "text/html";
                case "image/gif" -> "image/gif";
                case "image/png" -> "image/png";
                case "image/bmp" -> "image/bmp";
                case "image/jpeg" -> "image/jpeg";
                default -> throw new IllegalStateException("Unexpected value: " + Files.probeContentType(file.toPath()));
            };

            // Indsæt fil størrelse og fil type
            String content_string = String.format("Content-Length: %d\r\n", file_size);
            String content_type_string = String.format("Content-Type: %s\r\n", fileType);

            // Send HTTP header med status kode, filens størrelse, fil-type og dato
            bos.write("HTTP/1.0 200 \r\n".getBytes(StandardCharsets.UTF_8));
            bos.write(content_string.getBytes(StandardCharsets.UTF_8));
            bos.write(content_type_string.getBytes(StandardCharsets.UTF_8));
            bos.write(date.getBytes(StandardCharsets.UTF_8));
            bos.write("\r\n\r\n".getBytes(StandardCharsets.UTF_8));
            bos.flush();

            int nRead = 0;
            boolean readAll = false;
            int bufferSize = 1024; //1024 bytes
            byte[] buffer = new byte[bufferSize]; // Variable deklareres, så filen kan læses

            while (!readAll) {
                nRead = fin.read(buffer);
                if (nRead == -1) { // read() returnerer -1, hvis filen intet indeholder
                    fin.close();
                    readAll = true; // Stop løkken, hvis filen er læst igennem
                } else {
                    for (int i = 0; i < nRead; i++) {
                        bos.write(buffer[i]); // Skriver hver enkelt byte i filen til output stream
                    }
                }
            }
            bos.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Modtag request
     * @param client_socket åben socket
     * @return Empty string
     */
    public static String getRequest(Socket client_socket) {
        try {
            Scanner server_in = new Scanner(client_socket.getInputStream());
            PrintWriter pw = new PrintWriter(client_socket.getOutputStream());
            String text_line = "", first_line = server_in.nextLine();

            do {
                text_line = server_in.nextLine();
                System.out.println(text_line);
            } while (!text_line.equals(""));

            String requested_resource = first_line.split(" ")[1]; // HANDLE BLANK SPACE
            System.out.println(requested_resource);
            return requested_resource;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}
