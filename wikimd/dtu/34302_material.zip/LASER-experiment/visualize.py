# -*- coding: utf-8 -*-
from matplotlib import pyplot as plt 

files = ["100.0mA.txt", "110.0mA.txt", "125.0mA.txt", "150.3mA.txt", "175.0mA.txt", "202mA.txt", "225.0mA.txt", "250.0mA.txt", "275.0mA.txt", "300.0mA.txt"]

for file in files:
	with open('C:/Users/Daniel2/Dropbox/DTU2021/Cybertek/LASER-experiment/' + file) as f:
		data = f.readlines()

	splitlines = [i.split("\t") for i in data[4:]]

	wavelengths = [float(i[0].strip().replace(",", ".")) for i in splitlines]
	measurements = [float(i[1].strip().replace(",", ".")) for i in splitlines]

	plt.plot(wavelengths, measurements, 'o', marker=".", markersize="5")
plt.title("100.0mA")
plt.xlabel('Wavelength [nm]')
plt.ylabel("Measured power [dBm]")
plt.legend()
plt.show()