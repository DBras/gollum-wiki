package opgave3;

public class opgave3c {
    public static void main(String[] args) {
        int k = 5;
        doub(k);
        doub(k);
        if (k<= 19) {
            k++;
        }
        System.out.println(k);

    }
    public static void doub(int x) {
        x *= 2;
    }
}
