package opgave3;

public class opgave3d {
    public static void main(String[] args) {
        opg5(5,1);
    }
    public static void opg5(int a, int b) {
        for(int i=a; i<10; i++) {
            for(int j=1; j<=b; j++){
                System.out.print("1");
            }
            for(int j=3; j< i-b; j++){
                System.out.print("0");
            }
        }
    }
}
