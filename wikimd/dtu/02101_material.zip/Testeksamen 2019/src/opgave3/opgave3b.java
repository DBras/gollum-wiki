package opgave3;

import java.util.Scanner;

public class opgave3b {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int j = 0;
        for (int i = 0; i < 5; i++) {
            int k = input.nextInt();
            if (k%2==0) {
                j--;
            }
            else{
                j++;
            }
        }
        System.out.println(j);
    }
}
