package opgave1;

public class D {
    String a,b,c;
    public D(String x, String y){
         a = b = x;
         c = y;
    }
    public D() {
         a = b;
    }
}
