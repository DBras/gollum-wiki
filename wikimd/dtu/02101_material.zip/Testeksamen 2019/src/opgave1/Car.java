package opgave1;

public class Car {
    String make;
    public Car(String make) {
        this.make = make;
    }
    public void print() {
        System.out.println("This is a "+make);
    }
}
