package opgave1;

import java.awt.*;
import java.util.ArrayList;

public class Miscc {
    public static void main(String[] args) {
        int X = 100;
        for(int i=0; i<X; i++) {
            for (int j=0; j<i; j++) {
                System.out.println("A ");
            }
            System.out.println("B ");
        }
    }
}
