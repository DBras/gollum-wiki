package opgave1;

public class Truck extends Car{
    public Truck(String make) {
        super(make);
    }
    public void print() {
        System.out.println("This is a "+make+" truck");
    }
}
