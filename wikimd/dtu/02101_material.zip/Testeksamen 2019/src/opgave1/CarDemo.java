package opgave1;

public class CarDemo {
    public static void main(String[] args) {
        Truck truck = new Truck("Scania");
        truck.print();
    }
}
