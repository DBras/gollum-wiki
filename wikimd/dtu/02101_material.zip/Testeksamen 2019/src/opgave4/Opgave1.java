package opgave4;

public class Opgave1 {
    public static void main(String[] args) {
        int[] a = {1,4,2,3};
        System.out.println(opg1(a));
        System.out.println(opg1b(a));
    }
    public static int opg1(int[] a){
        int c1 = 0;
        int c2 = 0;
        for(int i = 0; i < a.length; i++) {
            if(a[i] % 2 == 2 % 2) {
                c1 = c1 + a[i]/2;
            } else{
                c1 = c1 + a[i]/2;
                c2 = c2 + 1;
            }
        }
        return 2*c1+c2;
    }
    public static int opg1b(int[] a) {
        int sum = 0;
        for(int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        return sum;
    }
}
