package opgave4;

public class Opgave2 {
    public static void main(String[] args) {
        System.out.println(opg2(-3,-9));
    }
    public static int opg2(int a, int b) {
        int i = 0;
        while (i*a<=b-a) {
            i++;
        }
        return i;
    }
}
