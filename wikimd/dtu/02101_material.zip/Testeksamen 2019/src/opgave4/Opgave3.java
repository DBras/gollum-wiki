package opgave4;

public class Opgave3 {
    public int c = 0;
    public static void main(String[] args) {
        System.out.println(opg3(4,1));
    }
    private static int opg3(int a, int b) {
        System.out.println("RUN");
        if (a<b) {
            return 0;
        }
        if (a==b) {
            return a;
        }
        return a * opg3(a-1,b);
    }
}
