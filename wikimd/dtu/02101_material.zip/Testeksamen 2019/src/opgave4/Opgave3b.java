package opgave4;

public class Opgave3b {
    public static void main(String[] args) {
        System.out.println(opg3b(4,1));
    }

    public static int opg3b(int a, int b) {
        int total = 1;
        for (int i = 0; i < a-b; i++) {
            total *= a-i;
        }
        return total;
    }
}
