package misc;

import java.util.Locale;

public class Misc {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 0; i < 5; i++){
            for (int j = 0; j < 5; j++) {
                for (int k = 0; k < 1;) {
                    System.out.println("Running");
                    sum++;
                }
            }
        }
        System.out.println(sum);
    }
    public static void m1 (Ship x) {
        x.setF1(4);
    }
}
