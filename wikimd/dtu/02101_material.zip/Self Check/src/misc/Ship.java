package misc;

public class Ship {
    public int f1 = 0;

    public Ship() {
        this.f1 = 2;
    }

    public void setF1(int newf1) {
        this.f1 = newf1;
    }

    public String toString() {
        return "Str: " + this.f1;
    }
}
