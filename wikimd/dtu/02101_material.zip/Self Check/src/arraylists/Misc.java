package arraylists;

import java.util.ArrayList;

public class Misc {
    public static void main(String[] args) {
        ArrayList<String> l = new ArrayList<String>(){
            {
                add("It");
                add("was");
                add("a");
                add("stormy");
                add("night");
            }
        };
        l.add(3,"dark");
        l.add(4, "and");
        l.set(1,"IS");

        for(int i = 0; i < l.size(); i++) {
            if (l.get(i).contains("a")) {
                l.remove(i);
                i--;
            }
        }

        System.out.println(l);

        // --------------------------------------------------
        ArrayList<Integer> l2 = new ArrayList<Integer>();
        for (int i = 2; i < 10*2; i+=2) {
            l2.add(i);
        }
        System.out.println(l2);


        // ---------------------------------------------------


    }

    public static int maxLength(ArrayList l2) {
        return 1;
    }
}
