package opgave1;

import java.util.Arrays;
import java.util.Random;

public class misc {
    public static void main(String[] args) {
        System.out.println((3*2 > 15 % 10) == (4 > 8 % 6 - 2));
    }
}
