package opgave1;

public class D<T> {
    T a;
    T b;
    public D(T x, T y) {
        a = x;
        b = y;
    }
    public D() {
        a=b;
    }
}
