package opgave4;

public class opg2 {
    public static void main(String[] args) {
        opg2(64);
    }

    public static void opg2(int i) {
        System.out.println(" ");
        if(i%2==0) {
            op2a(i);
        } else {
            opg2b(i);
        }
    }

    public static void op2a(int i) {
        System.out.println(i);
        opg2(i/2);
    }

    public static void opg2b(int i) {
        System.out.println("RUN");
        System.out.println(i);
        if(i==1) return;
        opg2(3*i+1);
    }
}
