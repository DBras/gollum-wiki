package opgave4;

public class opg2b {
    public static void main(String[] args) {
        opg2(10);
    }

    public static void opg2(int x) {
        while (x != 1) {
            System.out.println(x);
            if (x%2 == 0) {
                x = x / 2;
            } else {
                x = 3*x + 1;
            }
            System.out.println(" ");
        }
        System.out.println(1);
    }
}
