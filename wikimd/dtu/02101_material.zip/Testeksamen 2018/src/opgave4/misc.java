package opgave4;

public class misc {
    public static void main(String[] args) {
        System.out.println(opg1(-10));
    }

    public static int opg1(int x) {
        if (x <= 1) {
            return x;
        }
        int out = 1;
        for (int i = x; i > 0; i--) {
            out = out * i;
        }
        return out;
    }
}
