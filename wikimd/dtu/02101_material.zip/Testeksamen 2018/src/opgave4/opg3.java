package opgave4;

public class opg3 {
    public static void main(String[] args) {
        System.out.println(opg3(-10,10));
    }

    public static int opg3(int l, int r) {
        if (r < 1) return -opg3(r, l);
        int c = 0;
        for (int i = l; i < r; i++) {
            c++;
        }
        return c;
    }
}
