package opgave4;

public class opg3b {
    public static void main(String[] args) {
        System.out.println(opg3(-10, 10));
    }

    public static int opg3(int l, int r) {
        if (r < 1) return -(l - r);
        if (l > r) return 0;
        return r - l;
    }
}
