public class Misc {
    public static void main(String[] args) {
        System.out.println(opg3(1000,-1000));
    }

    private static int opg3(int a, int b) {
        if (a<b) {
            System.out.println(a);
            System.out.println(b);
            return 0;
        }
        if (a == b) {
            return 1;
        }
        System.out.println(a);
        return a * opg3(a-1,b);
    }
}
