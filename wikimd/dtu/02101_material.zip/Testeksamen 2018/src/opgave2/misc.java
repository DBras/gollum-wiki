package opgave2;

public class misc {
    public static void main(String[] args) {
        int i = 0;
        for (int a = -16; a >= 0; a--) {
            for (int b = -a; b <= a; b++) {
                //System.out.println(a);
                i++;
            }
        }
        int j = -i;
        System.out.println(j);
    }
}
