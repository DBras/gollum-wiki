package opgave2;

public class misc2 {
    public static void main(String[] args) {
        System.out.println(delA(32));
    }
    public static int delA(int i) {
        return delB(i,1);
    }
    public static int delB(int i, int j) {
        System.out.println("RUN " + i + " " + j);
        if (i<2) return j;
        if (i%2 == 0) {
            return delB(i/2, j+1);
        }
        else {
            return delB(i-1,j);
        }
    }
}
