package opgave3;

import java.util.Arrays;
import java.util.Scanner;

public class misc {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] tabel = new int[input.nextInt()];
        for (int i = tabel.length; i > 0; i--) {
            tabel[i-1] = input.nextInt();
        }
        System.out.println(Arrays.toString(tabel));
    }
}
