package opgave5;

public class Husnummer implements Comparable<Husnummer>{
    public final int nummer;
    public Husnummer(int nummer) {
        this.nummer = nummer;
    }
    public int compareTo(Husnummer h) {
        if(this.nummer == h.nummer) return 0;
        if (this.nummer%2 == 0) {
            if (h.nummer%2 == 0) {
                if(this.nummer < h.nummer) return -1;
                return 1;
            } else {
                return -1;
            }
        } else{
            if(h.nummer%2 == 1 && this.nummer > h.nummer){
                if(this.nummer > h.nummer) return -1;
            }
            return 1;
        }
    }
}
