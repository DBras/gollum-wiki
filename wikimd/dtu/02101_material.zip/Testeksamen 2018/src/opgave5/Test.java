package opgave5;

public class Test {
    public static void main(String[] args) {
        Husnummer A = new Husnummer(5);
        Husnummer B = new Husnummer(5);
        System.out.println(A.compareTo(B));
    }
}
