package opgave6;

public abstract class Figur {
    protected String type;
    public abstract int getVolume();
    public String toString() {
        return type+" på "+getVolume()+" kubikcentimeter";
    }
}
