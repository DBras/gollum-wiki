package opgave6;

public class Kube extends Figur {
    private int side_length;

    public Kube(int s) {
        this.side_length = s;
        this.type = "Kube";
    }

    public int getVolume() {
        return this.side_length*this.side_length*this.side_length;
    }
}
