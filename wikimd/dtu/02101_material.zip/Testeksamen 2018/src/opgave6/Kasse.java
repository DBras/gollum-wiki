package opgave6;

public class Kasse extends Figur{
    private int length;
    private int width;
    private int height;
    //private String type;

    public Kasse(int l, int w, int h) {
        this.length = l;
        this.width = w;
        this.height = h;
        this.type = "Kasse";
    }

    public int getVolume() {
        return this.height*this.width*this.length;
    }
}
