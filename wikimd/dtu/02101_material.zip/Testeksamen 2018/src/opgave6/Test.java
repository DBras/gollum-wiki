package opgave6;

public class Test {
    public static void main(String[] args) {
        Kasse k = new Kasse(2,3,4);
        System.out.println(k);

        Kube t = new Kube(3);
        System.out.println(t);

    }
}
