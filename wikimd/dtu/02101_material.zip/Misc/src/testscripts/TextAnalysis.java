package testscripts;

import java.io.File;
import java.util.Scanner;
//We import "java.io.File" and "java.util.Scanner" to read the 4 files


public class TextAnalysis {
    private static String[] tokens;
    private static String text;
    private static boolean zeroWords;
    //We define 3 variables so we can use them anywhere


    public TextAnalysis (String sourceFileName, int maxNoOfWords)
            throws Exception {
        //This program will open the files
        File file = new File(sourceFileName);
        Scanner inputfile = new Scanner(file);
        String textline;

        // Only run the next code if the file contains lines
        if (inputfile.hasNextLine()) {
            //We use a scanner to open the lines one at a time
            while (inputfile.hasNextLine()) {
                // This puts all the lines into the same string, separated by space
                textline = inputfile.nextLine();
                text = text + " "+textline;
            }
            inputfile.close();
            text = text.toLowerCase();
            //We set all the upper case letters to lower case letters
            tokens = text.split("[^a-zA-Z]+");
            //We use this method to split our words from each other
            // using regex - matching everything which is not an upper- or lowercase letter
            zeroWords = false;
            // This variable is used to indicate that the file is not empty
        }
        else {
            zeroWords = true; // The file is empty. This is used in subsequent methods
            // to return a count of 0
        }
    }

    public int wordCount() {
        if (zeroWords) {
            return 0;
        }
        return tokens.length-1; // Since the first word is null, return length minus one
    }

    public int getNoOfDifferentWords() {
        //We want to find out how many unique words there are in the file
        if (zeroWords) {
            return 0; // Return 0 if file was empty.
        }
        String unique = "";
        int dif = 0;
        for (int i = 0; i < tokens.length; i++) { // Loop through all words
            // If the unique-string contains the word, skip
            // Otherwise, add current word to unique and add 1 to dif
            if (!unique.contains(" "+tokens[i]+" ")) {
                unique += " "+tokens[i]+" ";
                dif++;
            }
        }
        return dif-1; // Again 1 is subtracted since the first word is null
    }

    public int getNoOfRepetitions() {
        //Here we want to find the number of immediate repetitions
        if (zeroWords) {
            return 0;
            //We first need to check if there are any words on the string
            //if not return 0
        }

        int immediate_repetitions = 0;
        for (int i = 0; i < tokens.length - 1; i++) {
            if (tokens[i].equals(tokens[i + 1])) {
                immediate_repetitions++;
                //We make a loop that will go though all words words and our "if" statement check if
                //the following word is identical
                //If yes we add 1 to "immediate_repetitions"
            }
        }
        return immediate_repetitions;
    }
}
