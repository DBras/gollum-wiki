package testscripts;

import java.lang.Math; // Imports the Math package to be used in the class.

public class MovingPoint {
    private double x, y, direction, speed,	// Defines the fields this class contains.
            radianangle, dx, dy;	// Defines variables to be used in later methods.

    public MovingPoint(double x, double y, double direction, double speed) {
        /* Main constructor of the class. Since no logic has to be applied to the coordinates,
         * these are simply set based on the parameters. Direction and speed, however,
         * have limitations, so the logic is moved to the setter functions and
         * the constructor calls these.
         */
        this.x = x;
        this.y = y;
        this.setDirection(direction);
        this.setSpeed(speed);
    }

    public MovingPoint() {
        /* Calls the main constructor if no arguments are given upon creation.
         * Constructs a MovingPoint with [x,y] = [0,0], direction 90° and speed 0.
         */
        this(0, 0, 90, 0);
    }

    public void setDirection(double direction) {
        /* Direction setter method. This method makes sure that the direction is an angle
         * in [0;360[ by taking the modulus 360 and then, if the angle is less than 0,
         * adding 360, since this is geometrically equivalent (-30° = 330°).
         */
        this.direction = direction % 360;
        if (this.direction < 0) {
            this.direction = 360 + this.direction;
        }
    }

    public void setSpeed(double speed) {
        /* Speed setter method. This makes sure that the speed is greather than 0
         * and less than or equal to 20. If not, the speed is set to the appropriate value.
         */
        this.speed = speed;
        this.speed = Math.max(this.speed, 0);  // Cannot be less than 0
        this.speed = Math.min(this.speed, 20); // Cannot be greater than 20
    }

    public void move(double duration) {
        /* Method for moving the point. It first uses Math.toRadians to convert the angle (in degrees)
         * to radians, since the Math.cos and Math.sin uses radians. The change per time unit is then
         * calculated by multiplying the speed with the sin or cos of the angle (cos for x, sin for y).
         * Then adds the change multiplied with the duration of the move to the coordinates.
         */
        radianangle = Math.toRadians(this.direction);
        dx = this.speed * Math.cos(radianangle);
        dy = this.speed * Math.sin(radianangle);
        this.x += dx * duration;
        this.y += dy * duration;
    }

    public void turnBy(double angle) {
        /* Method for turning the direction.This method merely calls the setDirection()-method
         *  with the parameter: current direction plus angle to turn by.
         */
        this.setDirection(this.direction + angle);
    }

    public void accelerateBy(double change) {
        /* Method for accelerating the point. This method calls the setSpeed()-method
         * with the parameter: current speed plus change of speed.
         *
         */
        this.setSpeed(this.speed + change);
    }

    public String toString() {
        /* Returns a string of the object in the format specified
         * in the assignment.
         */
        return String.format("[%f;%f] %f %f", this.x, this.y, this.direction, this.speed);
    }
}

