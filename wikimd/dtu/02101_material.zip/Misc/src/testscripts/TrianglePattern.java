package testscripts;
import java.util.Arrays; // snakkede sammen med Samuel Rana s214665

public class TrianglePattern {

    private int h,n;			//Here we declare our height and our length
    private int[][] matrix;		// Here we declare our matrix where the cells are located
    private int[] initial;
    private int Cell1, Cell2, Cell3;			// here we declare our variables Cell1, Cell2 and Cell3 in the matrix

    public TrianglePattern(int width, int height, int[] move) {// here the most important functions happen and the function
        this.h=height;									 	  //	needs to bed public so the other file TPViewer can access it
        this.n=width;
        this.initial = move;
        matrix = new int[height][width];

        int Matrix;
        for (int i=0; i<move.length; i++) {		// in this part we get the length of matrix and we put one extra row on
            Matrix = move[i];					// each time we are done with a row
            matrix[0][Matrix] = 1;				// this also moved the pattern to the right if move's value increases
        }

        for (int j=1; j<h; j++) {
            for (int i=1; i<n-1; i++) {					//in this function we have our cells/coordinats in our matrix
                Cell1=matrix[j-1][i-1];
                Cell2=matrix[j-1][i];
                Cell3=matrix[j-1][i+1];

                if ((Cell1==1 & Cell2==0 & Cell3==0) || (Cell1==0 & !(Cell2==0 & Cell3==0))){ //here we check if the cell is equal to 1 then in the other file
                    matrix[j][i]=1;														  // if the cell is equal to 1  the cell turn black
                }																		  //here we check if the cell is equal to 0 then in the other file
                // if the cell is equal to 1  the cell turn black and we need this
                // and we need ! to check if 0 is different from 0
            }
        }
    }

    public int getN() {			//Here we get our length returned
        return n;
    }
    public int getH() { 		//Here we get our height returned
        return h;
    }
    public int getValueAt(int r, int c) { // here we get our cells size and at what row they are placed one
        return matrix[r][c];
    }

    public int[] getInitial() { // this returns how far the pattern
        return initial;
    }
}
