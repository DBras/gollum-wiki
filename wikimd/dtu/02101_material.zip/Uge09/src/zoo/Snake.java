package zoo;

public class Snake extends Reptile{
    public Snake() {
        super(0, "Snake");
    }
}
