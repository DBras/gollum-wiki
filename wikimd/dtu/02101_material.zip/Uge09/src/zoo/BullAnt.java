package zoo;

public class BullAnt extends Insect{
    public BullAnt() {
        super("Bull ant");
    }
}
