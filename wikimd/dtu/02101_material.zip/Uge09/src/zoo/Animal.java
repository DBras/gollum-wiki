package zoo;

public abstract class Animal {
    private int legs;
    private String name;

    public Animal(int legs, String name) {
        this.legs = legs;
        this.name = name;
    }

    public int getLegs() {
        return this.legs;
    }

    public String toString() {
        return this.name;
    }

    public abstract boolean laysEggs();
}
