package zoo;

public class Mammal extends Animal{
    public Mammal(int legs, String name) {
        super(legs, name);
    }

    public boolean laysEggs() {
        return false;
    }
}
