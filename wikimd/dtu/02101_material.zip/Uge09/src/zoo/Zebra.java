package zoo;

public class Zebra extends Mammal{
    public Zebra() {
        super(4, "Zebra");
    }
}
