package zoo;

public class Insect extends Animal{
    public Insect(String name) {
        super(6, name);
    }

    public boolean laysEggs() {
        return true;
    }
}
