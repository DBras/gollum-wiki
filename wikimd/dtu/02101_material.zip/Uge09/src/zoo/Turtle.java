package zoo;

public class Turtle extends Reptile{
    public Turtle() {
        super(4, "Turtle");
    }
}
