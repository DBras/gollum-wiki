package zoo;

public class Giraffe extends Mammal{
    public Giraffe() {
        super(4, "Giraffe");
    }
}
