package zoo;

public class Reptile extends Animal{
    public Reptile(int legs, String name) {
        super(legs, name);
    }

    public boolean laysEggs() {
        return true;
    }
}
