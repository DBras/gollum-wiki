package zoo;

public class Elephant extends Mammal{
    public Elephant() {
        super(4, "Elephant");
    }
}
