package skak;

public class Loeber extends Skakbrik{
    public Loeber(int x, int y, String colour) {
        super(x, y, colour, "loeber");
    }

    public void translate(int dx, int dy) {
        if ((dx*dx == dy*dy) && super.withinBounds(dx,dy)) {
            this.x += dx;
            this.y += dy;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
}
