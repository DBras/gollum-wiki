package skak;

public class Dronning extends Skakbrik{
    public Dronning(int x, int y, String colour) {
        super(x, y, colour, "dronning");
    }

    public void translate(int dx, int dy) {
        if ((((dx*dx <= 1 && dy*dy <= 1)
                || ((dx == 0) || (dy == 0)))
                || (dx*dx == dy*dy))
                && super.withinBounds(dx,dy)) {
            this.x += dx;
            this.y += dy;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
}
