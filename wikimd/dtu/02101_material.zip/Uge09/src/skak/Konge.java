package skak;

public class Konge extends Skakbrik{
    public Konge(int x, int y, String colour) {
        super(x, y, colour, "konge");
    }

    public void translate(int dx, int dy) {
        if ((dx*dx <= 1 && dy*dy <= 1)
                && super.withinBounds(dx,dy)) {
            this.x += dx;
            this.y += dy;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
}
