package skak;

public class Springer extends Skakbrik{
    public Springer(int x, int y, String colour) {
        super(x, y, colour, "springer");
    }

    public void translate(int dx, int dy) {
        if ((dx*dx == 4 && dy*dy == 1) || (dx*dx == 1 && dy*dy == 4)
                && super.withinBounds(dx, dy)) {
            this.x += dx;
            this.y += dy;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
}
