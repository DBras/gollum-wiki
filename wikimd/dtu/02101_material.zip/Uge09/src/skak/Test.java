package skak;

public class Test {
    public static void main(String[] args) {
        Dronning hd2 = new Dronning(5,3,"hvid");
        try{
            hd2.translate(0, 20);
            System.out.println(hd2);
        } catch (IllegalArgumentException e) {
            System.out.println("exception som forventet");
        }
    }
}
