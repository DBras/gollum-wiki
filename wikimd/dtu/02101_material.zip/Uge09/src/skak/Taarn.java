package skak;

public class Taarn extends Skakbrik{
    public Taarn(int x, int y, String colour) {
        super(x, y, colour, "taarn");
    }

    public void translate(int dx, int dy) {
        if (((dx == 0) || (dy == 0))
                && super.withinBounds(dx,dy)) {
            this.x += dx;
            this.y += dy;
        }
        else {
            throw new IllegalArgumentException();
        }
    }
}
