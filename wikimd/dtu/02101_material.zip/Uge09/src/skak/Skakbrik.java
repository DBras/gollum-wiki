package skak;

import java.awt.*;

public abstract class Skakbrik extends Point {
    private String colour, name;

    public Skakbrik(int x, int y, String colour, String name) {
        if ((x >= 0 && x <= 7) && (y >= 0 && y <= 7)){
            this.x = x;
            this.y = y;
            this.colour = colour;
            this.name = name;
        }
        else {
            throw new IllegalArgumentException();
        }
    }

    public boolean withinBounds(int dx, int dy) {
        return (this.x + dx >= 0 && this.x + dx <= 7)
                && (this.y + dy >= 0 && this.y + dy <= 7);
    }

    public String toString() {
        return this.colour + " " + this.name + " "
                + (String.valueOf((char)(this.x + 65))) + (this.y + 1);
    }

    public abstract void translate(int dx, int dy);
}
