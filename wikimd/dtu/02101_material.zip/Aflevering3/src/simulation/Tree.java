package simulation;

import java.awt.Point;

public class Tree extends Plant{

	private int s = PeberholmConstantsAndUtilities.TREE_SEED_NO;
	private int r = PeberholmConstantsAndUtilities.TREE_RANGE;
	private int MAX_Growth_X;
	private int MIN_Growth_X;
	private int MAX_Growth_Y;
	private int MIN_Growth_Y;
	
		public Tree(Point position) {
			this.position = position;

			this.color = PeberholmConstantsAndUtilities.TREE_COLOR;

			MIN_Growth_X = this.position.x - r; 
			MAX_Growth_X = this.position.x + r;
			MIN_Growth_Y = this.position.y - r; 
			MAX_Growth_Y = this.position.y + r;
		}
		public Plant[] spreadSeeds() {
			Plant[] newPlants = new Plant[s];

			for (int i = 0; i < s; i++){
				newPlants[i] = new Tree(new Point(
					PeberholmConstantsAndUtilities.getRandomIntBetween(MIN_Growth_X,MAX_Growth_X),
					PeberholmConstantsAndUtilities.getRandomIntBetween(MIN_Growth_Y,MAX_Growth_Y)
				));
			}

			return newPlants;
		} 

		public String toString() {
			return "Tree position ["+position.x+";"+position.y+"]";
		}
	}
