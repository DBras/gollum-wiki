package simulation;

public class PeberholmDriver {
		public static void main(String[] args) {
			//PeberholmSimulation phs = new PeberholmSimulation();
			PeberholmSimulationChecker phs = new PeberholmSimulationChecker ();
		}
		

	}
