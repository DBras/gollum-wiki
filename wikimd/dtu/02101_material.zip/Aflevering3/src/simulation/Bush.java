package simulation;

import java.awt.Point;

public class Bush extends Plant {

	private int s = PeberholmConstantsAndUtilities.BUSH_SEED_NO;
	private int r = PeberholmConstantsAndUtilities.BUSH_RANGE;
	
	private int MAX_Growth_X;
	private int MIN_Growth_X;
	private int MAX_Growth_Y;
	private int MIN_Growth_Y;
	
		public Bush(Point position) {
			this.position = position;

			this.color = PeberholmConstantsAndUtilities.BUSH_COLOR;

			MIN_Growth_X = this.position.x - r; 
			MAX_Growth_X = this.position.x + r;
			MIN_Growth_Y = this.position.y - r; 
			MAX_Growth_Y = this.position.y + r;
		} 
		public Plant[] spreadSeeds() {
			Plant[] newPlants = new Plant[s];

			for (int i = 0; i < s; i++){
				newPlants[i] = new Bush(new Point(
					PeberholmConstantsAndUtilities.getRandomIntBetween(MIN_Growth_X,MAX_Growth_X),
					PeberholmConstantsAndUtilities.getRandomIntBetween(MIN_Growth_Y,MAX_Growth_Y)
				));
			} 
			System.out.print(newPlants.length);
			return newPlants;
		}

		public String toString() {
			return "Bush position ["+position.x+";"+position.y+"]";
		}
		
}