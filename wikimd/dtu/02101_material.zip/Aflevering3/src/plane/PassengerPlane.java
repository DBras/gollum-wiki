package plane;

public class PassengerPlane extends Plane{
    private int seats;

    public PassengerPlane(String manufacturer, String type, int seats) {
        // Constructor of PassengerPlane which uses the super constructor
        // as well as setting the field seats
        super(manufacturer, type);
        this.seats = seats;

    }

    public String toString() {
        // Returns the super.toString with the seats-information added
        return String.format("%s seats:%d", super.toString(), this.seats);
    }
}
