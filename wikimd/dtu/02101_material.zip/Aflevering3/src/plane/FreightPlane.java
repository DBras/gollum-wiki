package plane;

public class FreightPlane extends Plane{
    private int payload;

    public FreightPlane(String manufacturer, String type, int payload) {
        // Constructor of FreightPlane which calls the super constructor
        // and then sets the special payload field.
        super(manufacturer, type);
        this.payload = payload;
    }

    public String toString() {
        // Uses the super.toString() while also writing the payload details
        return String.format("%s payload:%d", super.toString(), this.payload);
    }
}
