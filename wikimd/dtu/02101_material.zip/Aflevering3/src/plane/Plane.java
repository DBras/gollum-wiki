package plane;


public class Plane {


    private static final int DEFAULT_ID = 0;

    protected String manufacturer, type;
    int id;
    /**
     * @param manufacturer
     * @param type
     * @param id
     */
    public Plane(String manufacturer, String type) {
        // Plane constructor. Assigns the default ID to the plane as well as
        // setting the fields manufatorer and type
        this.manufacturer = manufacturer;
        this.type = type;
        this.id = DEFAULT_ID;
    }



    public void setId(int id){
        this.id = id;
    } // Sets the ID of the plane


    public String toString(){
        // toString-method. Returns the plane details in the requested format
        return (String.format("Plane%d %s %s",this.id, this.manufacturer, this.type));
    }


    public boolean equals(Object o){
        // Returns true if and only if the input parameter is a plane with
        // ID equal to this instance of Plane
        if (o instanceof Plane) { // Checks if o is of type Plane
            Plane e = (Plane) o; // Casts o to Plane
            return (this.getId() == e.getId()); // true if ID of o is equal to id of this instance
        } else {
            return false;
        }
    }

    public int getId() {
        return id;
    } // Returns ID of the plane. Used in the equals-method.



}