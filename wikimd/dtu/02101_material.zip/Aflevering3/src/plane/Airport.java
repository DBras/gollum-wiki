package plane;

import java.util.ArrayList; // ArrayList is used to store the planes

public class Airport {
    private ArrayList<Plane> plane_list = new ArrayList<Plane>();
    private int nextID = 1; // Create list of planes as well as ID to be used next

    public void land(Plane plane) {
        // This method checks the ID of the landing plane with all of
        // the planes already in the airport. If the plane ID is unique,
        // the plane is added to the airport. Otherwise it is ignored.
        int amount_of_planes = plane_list.size();
        boolean plane_unique = true;
        for (int i = 0; i < amount_of_planes; i++) {
            if (plane.getId() == plane_list.get(i).getId()) {
                plane_unique = false;
                break; // Break if the ID is not unique
            }
        }
        if (plane_unique) {
            plane_list.add(plane);
            plane.setId(nextID);
            nextID++;
        }
    }

    public void start(int id) { // Checks to see if the requested ID is in the aiport
        for (int i = 0; i < plane_list.size(); i++) {
            if (plane_list.get(i).getId() == id) {
                plane_list.remove(i);
                break; // If the plane exists, it is deleted from the list and the loop breaks
            }
        }
    }

    public String toString() {
        // Returns a string of all the planes with line breaks after
        // each plane. Uses the defined toString()-method in the Plane class
        String out = "";
        for (Plane p : plane_list) {
            out += p.toString() + "\n";
        }
        return out;
    }
}
