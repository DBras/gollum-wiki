import java.util.ArrayList;

public class SkibsRegister {
    public static void main(String[] args) {
        ArrayList<String> skibe = new ArrayList<String>();
        skibe.ad
    }
}
