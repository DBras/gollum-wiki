package testex3;

public class Tandem extends Cykel{
    protected int antalSaeder;

    public Tandem(String stelnummer) {
        super(stelnummer);
    }

    public void setAntalSaeder(int antalSaeder) {
        this.antalSaeder = antalSaeder;
    }
}
