package testex3;

public class Cykel {
    protected String stelnummer;
    protected int hjulDiameterITommer;

    public Cykel(String stelnummer) {
        this.stelnummer = stelnummer;
    }

    public void setHjulDiameterITommer(int hjulDiameterITommer) {
        this.hjulDiameterITommer = hjulDiameterITommer;
    }

    public double getHjuldiameterICm() {
        return this.hjulDiameterITommer * 2.54;
    }
}
