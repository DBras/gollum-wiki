package testex3;

public class CykelTest {
    public static void main(String[] args) {
        Cykel[] cykler = new Cykel[2];
        cykler[0] = new Cykel("c1");
        cykler[0].setHjulDiameterITommer(28);
        cykler[1] = new Tandem("t1");
        cykler[1].setHjulDiameterITommer(26);
        cykler[1].setAntalSaeder(3);

    }
}
