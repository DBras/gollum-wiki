package client;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) {
        String URL = "ftnk-ctek01.win.dtu.dk";
        int port = 1060;
        Socket sock = null;
        String nextLine = "";
        Scanner console = new Scanner(System.in); // Variables for later use are initialized

        try { // Try to create socket and run script, otherwise print exception
            sock = new Socket(URL, port); // Initialize connection and create in/out streams
            BufferedReader bir = new BufferedReader(
                    new InputStreamReader(sock.getInputStream()));
            PrintWriter pw = new PrintWriter(sock.getOutputStream());

            while (true) { // Run until the loop is broken by game ending
                while (!nextLine.equals("YOUR TURN")) { // Run as long as the server sends
                    nextLine = getNextLine(bir);
                    if (nextLine.substring(0, 8).equals("BOARD IS")) { // Pretty print board
                        printBoard(nextLine);
                    }
                    else if (nextLine.equals("YOUR TURN")) {
                        System.out.print("YOUR MOVE: ");
                    }
                    else if (nextLine.endsWith("WINS")) { // Stop loop if game ends (PLAYER WINS,
                                                          // COMPUTER WINS, NOBODY WINS
                        break;
                    }
                    else {
                        System.out.println(nextLine); // Print whatever the server sends
                    }
                }
                if (!nextLine.endsWith("WINS")) { // If game hasn't ended, let the user send input
                    pw.print(console.nextLine() + "\r\n");
                    pw.flush();
                    nextLine = ""; // Reset nextLine so the above while loop runs
                }
                else {break;}
            }
            System.out.println(nextLine); // Print final line from server

            sock.close(); // Close socket
        } catch (IOException e) {
            e.printStackTrace(); // Print exception if socket couldn't be created
        }
    }

    public static String getNextLine(BufferedReader bir) { // Method for getting next line from server
        String line = "";
        while (true) { // Try until readLine() returns a value
            try {
                line = bir.readLine();
                break;
            } catch (Exception e) { // Catch exception if the server hasn't sent a full line.
                                    // Simply runs the loop again
                continue;
            }
        }
        return line; // Return the full line received from server
    }


    public static void printBoard(String board) { // Pretty print the board
        board = board.substring(9,18); // Select the part of the line with the board details
        String c;
        String printer =
                "-------------\n" +
                "| pos1 | pos2 | pos3 |\n" +
                "-------------\n" +
                "| pos4 | pos5 | pos6 |\n" +
                "-------------\n" +
                "| pos7 | pos8 | pos9 |\n" +
                "-------------\n";
        // Replace the positions with the corresponding with the board positions
        for (int i = 0; i < 9; i++) {
            c = Character.toString(board.charAt(i));
            printer = printer.replace("pos" + (i + 1), c);
        }
        System.out.println(printer); // Print the board
    }
}
