package server;

import java.net.Socket;
import java.net.ServerSocket;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Scanner;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.TimeZone;

public class main {
    public static void main(String[] args) {
        ServerSocket server_sock = null;
        boolean server_active = true;
        try {
            server_sock = new ServerSocket(8080);
            while (server_active) {
                try {
                    Socket client_socket = server_sock.accept();

                    String requested_resource = getRequest(client_socket);
                    if (requested_resource.equals("/LUK")) {
                        server_active = false;
                    }
                    //Files.list(Paths.get("./html")).forEach(path -> System.out.println(path));
                    sendResource(requested_resource, client_socket);


                    client_socket.shutdownInput();
                    client_socket.shutdownOutput();
                    client_socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            server_sock.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getDate() {
        SimpleDateFormat gmtFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.
                ENGLISH
        );
        gmtFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        String gmtString = gmtFormat.format(Calendar.getInstance().getTime());
        return gmtString;
    }

    public static void sendResource(String request, Socket client_socket) {
        try {
            BufferedOutputStream bos = new BufferedOutputStream(client_socket.getOutputStream());
            byte[] buffer = new byte[1024];
            boolean readAll = false, file_exists = false;
            int nRead = 0;
            int b;
            FileInputStream fin = null;

            String date = "Date: " + getDate();

            try {
                File file = new File("./html" + request);
                fin = new FileInputStream(file);
                file_exists = true;
            } catch (FileNotFoundException e) {
                bos.write("HTTP/1.0 404 \r\n".getBytes(StandardCharsets.UTF_8));
                bos.write("Content-Length: 0\r\n".getBytes(StandardCharsets.UTF_8));
                bos.write(date.getBytes(StandardCharsets.UTF_8));
                bos.write("\r\n\r\n".getBytes(StandardCharsets.UTF_8));
                bos.flush();
            }

            if (file_exists) {
                nRead = fin.read(buffer);

                String content_string = String.format("Content-Length: %d\r\n", nRead);
                bos.write("HTTP/1.0 200 \r\n".getBytes(StandardCharsets.UTF_8));
                bos.write(content_string.getBytes(StandardCharsets.UTF_8));
                bos.write("Content-Type: text/html\r\n".getBytes(StandardCharsets.UTF_8));
                bos.write(date.getBytes(StandardCharsets.UTF_8));
                bos.write("\r\n\r\n".getBytes(StandardCharsets.UTF_8));
                bos.flush();

                Path path = Paths.get("./html/"+request);
                byte[] data = Files.readAllBytes(path);
                bos.write(data);
                bos.flush();
            }


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String getRequest(Socket client_socket) {
        try {
            Scanner server_in = new Scanner(client_socket.getInputStream());
            PrintWriter pw = new PrintWriter(client_socket.getOutputStream());
            String text_line = "", first_line = server_in.nextLine();

            do {
                text_line = server_in.nextLine();
                System.out.println(text_line);
            } while (!text_line.equals(""));

            String requested_resource = first_line.split(" ")[1]; // HANDLE BLANK SPACE
            System.out.println(requested_resource);
            return requested_resource;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }
}
