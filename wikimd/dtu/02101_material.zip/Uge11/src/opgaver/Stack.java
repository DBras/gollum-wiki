package opgaver;

import java.util.ArrayList;

public class Stack<T> {
    private T t;
    private ArrayList<T> stack = new ArrayList<T>();

    public void push (T o) {
        stack.add(o);
    }

    public T pop() {
        if (this.empty()) {
            return null;
        }
        T element = stack.get(stack.size()-1);
        stack.remove(stack.size()-1);
        return element;
    }

    public boolean empty() {
        return (stack.size() < 1);
    }
}
