package opgaver;

import java.util.ArrayList;

public class ArrayListX {

    public static void append(ArrayList<Integer> list1, ArrayList<Integer> list2) {
        for (int s : list2) {
            list1.add(s);
        }
    }

    public static ArrayList<Integer> merge(ArrayList<Integer> list1, ArrayList<Integer> list2) {
        ArrayList<Integer> res = new ArrayList<Integer>();

        for (int i = 0; i < Math.max(list1.size(), list2.size()); i++) {
            try {
                res.add(list1.get(i));
            } catch (IndexOutOfBoundsException e) {}
            try {
                res.add(list2.get(i));
            } catch (IndexOutOfBoundsException e) {}
        }

        return res;
    }

    public static void printList(ArrayList<Integer> list, String name) {
        System.out.println("------------------------\n"+name+":\n");
        for (int i = 0; i <list.size(); i++) {
            System.out.println(list.get(i));
        }

    }
}