package opgaver;

public class StackTest {

    public static void main(String[] args) {
        test01();
    }



    private static void test02() {
        Stack<Integer> stack = new Stack<Integer>();
        for (int i = 0; i < 1200; i++) {
            stack.push(i*i-753*i+19);
        }
        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
        for (int i = 0; i < 845; i++) {
            stack.pop();
        }
        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());

    }



    private static void test01() {
        Stack<String> stack = new Stack<String>();
        stack.push("bottom");
        stack.push("one over bottom");
        stack.push("two over bottom");
        stack.push("three over bottom");

        while (!stack.empty()) {
            System.out.println(stack.pop());
        }

        stack.push("jul");
        stack.push("oel");
        stack.push("sne");
        stack.push("oel");
        stack.pop();
        stack.pop();
        stack.push("Hvede");
        stack.push("oel");

        while (!stack.empty()) {
            System.out.println(stack.pop());
        }

    }

}
